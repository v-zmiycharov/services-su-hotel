docs - документация и презентация
HotelsServicesBPEL - BPEL процес
soa-java-soap - java soap услуги
src - .NET MVC приложение и .NET REST услуги
DB.sql - скрипт за генериране на Microsoft SQL база от данни
documentation.pdf - документация на проекта